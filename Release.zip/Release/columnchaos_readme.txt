Column Chaos
Filename: columnchaos.bsp
Release: April 16th, 2020
Author: Luke McPherson
Location: https://github.com/TheAurelian/Quake-Multiplayer-Level

Competitive free-for-all multiplayer level for 2-4 players for Quake.

See the project [wiki](https://github.com/TheAurelian/Quake-Multiplayer-Level/wiki) for more info 

**Copyright / Permissions**

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.

You MAY distribute this file, provided you include this text file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.  I have received permission from the original authors of any
modified or included content in this file to allow further distribution.